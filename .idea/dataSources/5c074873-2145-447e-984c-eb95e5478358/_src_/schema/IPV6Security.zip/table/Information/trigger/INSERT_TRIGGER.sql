CREATE TRIGGER IPV6Security.INSERT_TRIGGER
AFTER INSERT ON IPV6Security.Information
FOR EACH ROW
  BEGIN
		replace into System(`key`, `value`) values('time', now());
END;
