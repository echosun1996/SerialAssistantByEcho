CREATE PROCEDURE IPV6Security.AddColumnUnlessExists()
  BEGIN

IF NOT EXISTS (
	SELECT
		*
	FROM
		IPV6Security.System
	WHERE
		`key` = `time`
) THEN
SELECT CURRENT_TIMESTAMP;
	INSERT INTO IPV6Security.System (`key`, `value`)
VALUES
	(time, CURRENT_TIMESTAMP);
END
IF;


END;
