CREATE VIEW ScoreManagement.display AS
  SELECT
    `ScoreManagement`.`Students`.`No`         AS `学号`,
    `ScoreManagement`.`Students`.`Stu_Name`   AS `姓名`,
    `ScoreManagement`.`Students`.`Stu_Finish` AS `完成总数`,
    `ScoreManagement`.`Students`.`RankSum`    AS `排名和`
  FROM `ScoreManagement`.`Students`
  WHERE ((`ScoreManagement`.`Students`.`Stu_Finish` <> 0) AND (`ScoreManagement`.`Students`.`RankSum` <> 0))
  ORDER BY `ScoreManagement`.`Students`.`Stu_Finish` DESC;
