CREATE TRIGGER ScoreManagement.insert_on_management
AFTER INSERT ON ScoreManagement.Students
FOR EACH ROW
  BEGIN INSERT INTO Management.ec_score_score (NO,Stu_name,Email,QQ,Stu_Finish,RankSum)VALUES(new. NO,new.Stu_name,new.Email,new.QQ,new.Stu_Finish,	new.RankSum	) ;END;
