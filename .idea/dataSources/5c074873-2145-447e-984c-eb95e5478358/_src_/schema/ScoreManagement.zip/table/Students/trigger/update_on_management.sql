CREATE TRIGGER ScoreManagement.update_on_management
AFTER UPDATE ON ScoreManagement.Students
FOR EACH ROW
  BEGIN UPDATE Management.ec_score_score SET Stu_Finish=new.Stu_Finish WHERE Management.ec_score_score.No=new.No;UPDATE Management.ec_score_score SET RankSum=new.RankSum WHERE Management.ec_score_score.No=new.No;END;
