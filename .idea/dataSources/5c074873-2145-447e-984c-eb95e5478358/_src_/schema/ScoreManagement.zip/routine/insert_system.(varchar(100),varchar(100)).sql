CREATE PROCEDURE ScoreManagement.insert_system(IN name VARCHAR(100), IN value VARCHAR(100))
  BEGIN INSERT INTO System(Sys_Name,Sys_Value)VALUES(name,value);END;
